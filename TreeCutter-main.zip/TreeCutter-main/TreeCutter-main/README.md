﻿<div align="center">

# TreeCutter
[![Ko-fi](https://raw.githubusercontent.com/Fluxoah/Banners/main/available_for_paper.png)](https://modrinth.com/plugin/tree-cutter+/versions?l=paper)
[![Ko-fi](https://raw.githubusercontent.com/Fluxoah/Banners/main/available_for_pupur.png)](https://modrinth.com/plugin/tree-cutter+/versions?l=purpur)
[![Ko-fi](https://raw.githubusercontent.com/Fluxoah/Banners/main/available_on_modrinth.png)](https://modrinth.com/plugin/tree-cutter+)

TreeCutter is a lightweight and configurable Minecraft plugin that allows players to cut down entire natural trees instantly by sneaking and breaking the bottom log. Tool durability is respected, commands are LuckPerms-friendly, and admins have full control.

</div>

---

## Features

- Instant tree cutting when sneaking and breaking the bottom log.
- Leaves are felled together with the tree and never consume tool durability (toggleable via `behavior.cut-leaves`).
- Tool durability handling with Unbreaking support.
- Durability break confirmation (crouch + break again) with silent confirmed break; the on-screen warning lasts a configurable `behavior.confirmation-time-seconds` (default 7s).
- Leaf decay matches vanilla: leaves only decay when the whole trunk is felled and lose all nearby log support, dropping their natural drops (nothing/stick/apple for oak).
- Player-made tree blocking with a dedicated toggle: `behavior.block-player-made-trees`.
- Tracking for player-placed and command-placed logs (`setblock` / `fill`) with configurable max fill volume.
- WorldGuard compatibility with strict block-break checks and a per-region `treecutter` flag (`allow` = plugin works, `deny` = disabled in that region).
- Blacklist system with action-bar warnings and `/tcmsg off` to hide blacklist warnings.
- Unblacklist action-bar notice, including delivery when the player joins later.
- Prefix and messages fully configurable through `config.yml` and `messages.yml`.
- Compatible with Paper, Purpur, Spigot, and Bukkit on 1.21.x through 26.x, including Folia (regionised scheduling).

---

## Installation

1. Download the `TreeCutter-universal.jar` (works on every 1.21.x through 26.x server)
   or a version-specific `TreeCutter-<version>.jar`.
2. Place it in the server's `plugins` folder.
3. Start the server to generate default config files:
`config.yml`
`messages.yml`
4. Configure options as needed.
5. Restart the server (or run `/tcadmin reload`) to apply changes.

> A universal jar is shipped in addition to the per-version jars (see [Building from source](#building-from-source)).

---

## Building from Source

The plugin is built once per supported Minecraft version. Each version is a Gradle
subproject (`v1_21`, `v1_21_1`, ..., `v26_2`, `vuniversal`) that compiles the
**shared** sources in `src/main` against that version's Paper API and emits a
versioned jar.

```bash
./gradlew buildAll        # Linux/macOS
.\gradlew.bat buildAll    # Windows
```

All jars are collected into `build/libs/1.21.x/`, `build/libs/26.x/`, and
`build/libs/universal/`. The per-version jars are each compiled against their own
Paper API; `TreeCutter-universal.jar` is compiled once against the oldest
supported API (1.21) and runs on every version from 1.21.x through 26.x. Every
jar runs on Paper, Purpur, Spigot, and Bukkit; Folia is detected at runtime and
uses regionised scheduling through a reflection-based adapter, so no separate
Folia build is needed. Everything generated (subproject scaffolding, build output,
jars) lives inside `build/` — nothing is produced elsewhere in the repository.

- Shared plugin code lives in `src/main/java` and `src/main/resources`.
- Per-version overrides (optional) live in `build/subprojects/<version>/src/main/{java,resources}`
  (these are gitignored and recreated on demand).
- To release a new Minecraft version: append it to `versions` in `settings.gradle`
  and add its Paper API coordinate + Java release to `versionMeta` in `build.gradle`.

**Supported versions:** 1.21, 1.21.1, 1.21.2, 1.21.3, 1.21.4, 1.21.5, 1.21.6,
1.21.7, 1.21.8, 1.21.9, 1.21.10, 1.21.11, 26.1, 26.1.1, 26.1.2, 26.2.

---

## Commands

### Player Commands

| Command        | Permission                    | Description                                 |
|----------------|-------------------------------|---------------------------------------------|
| `/tc on`       | `treecutter.command.tc.on`    | Enable TreeCutter for the player            |
| `/tc off`      | `treecutter.command.tc.off`   | Disable TreeCutter for the player           |
| `/tc status`   | `treecutter.command.tc.status`| Show player status                          |
| `/tc help`     | `treecutter.command.tc.help`  | Show available player commands              |
| `/tcmsg off`   | `treecutter.command.tcmsg`    | Hide blacklist action-bar warnings          |

### Admin Commands

| Command                             | Permission                         | Description                                   |
|-------------------------------------|------------------------------------|-----------------------------------------------|
| `/tcadmin on`                       | `treecutter.command.tcadmin.on`    | Enable plugin globally                        |
| `/tcadmin off`                      | `treecutter.command.tcadmin.off`   | Disable plugin globally                       |
| `/tcadmin reload`                   | `treecutter.command.tcadmin.reload`| Reload config and messages                    |
| `/tcadmin check <player>`           | `treecutter.command.tcadmin.check` | View player stats                             |
| `/tcadmin blacklist add <player>`   | `treecutter.command.tcadmin.blacklist` | Add player to blacklist                   |
| `/tcadmin blacklist remove <player>`| `treecutter.command.tcadmin.blacklist` | Remove player from blacklist               |
| `/tcadmin blacklist list`           | `treecutter.command.tcadmin.blacklist` | List blacklisted players                  |
| `/tcadmin help`                     | `treecutter.command.tcadmin.help`  | Show admin commands                           |

> Admin commands are only visible to users with permission.

---

## Permissions

- `treecutter.use` -> Allows cutting trees
- `treecutter.command.tc` -> Base access to `/tc`
- `treecutter.command.tcmsg` -> Access to `/tcmsg`
- `treecutter.command.tc.*` -> Grants every `/tc` sub-command (handy with LuckPerms)
- `treecutter.command.tc.on` -> Access to `/tc on`
- `treecutter.command.tc.off` -> Access to `/tc off`
- `treecutter.command.tc.status` -> Access to `/tc status`
- `treecutter.command.tc.help` -> Access to `/tc help`
- `treecutter.command.tcadmin` -> Base access to `/tcadmin`
- `treecutter.command.tcadmin.*` -> Grants every `/tcadmin` sub-command (handy with LuckPerms)
- `treecutter.command.tcadmin.on` -> Access to `/tcadmin on`
- `treecutter.command.tcadmin.off` -> Access to `/tcadmin off`
- `treecutter.command.tcadmin.reload` -> Access to `/tcadmin reload`
- `treecutter.command.tcadmin.blacklist` -> Access to blacklist admin actions
- `treecutter.command.tcadmin.check` -> Access to `/tcadmin check`
- `treecutter.command.tcadmin.help` -> Access to `/tcadmin help`
- `treecutter.bypass.worldguard` -> Bypass WorldGuard checks

> Permissions are fully enforced with LuckPerms. OP fallback only applies if LuckPerms is not installed.
> Player-name suggestions (including offline players, like `/ban`) are shown for
> `/tcadmin check <player>` and `/tcadmin blacklist add|remove <player>`.

---

## Configuration Files

### `config.yml`

<details>
<summary><strong>Configs</strong></summary>

<br>

```yaml
enabled: true

disabled-players: []
blacklist: []
blacklist-message-disabled: []
pending-unblacklist-notice: []
prefix: "&8[&3T&bC&8]"

behavior:
  sneak-required: true
  block-player-made-trees: true
  require-axe: false
  max-tree-size: 256
  cooldown-seconds: 1.0
  confirmation-required: true
  confirmation-time-seconds: 7
  cut-leaves: true

  tree-detection:
    max-leaf-search-radius: 3
    max-leaf-search-up: 5
    min-leaf-count: 4
    max-horizontal-spread: 6
    require-upward-growth: true

placed-log-tracking:
  player-placed: true
  command-placed: true
  max-fill-volume: 50000

notifications:
  blacklist-actionbar-seconds: 10
  unblacklist-actionbar-seconds: 10

drops:
  drop-items: true
  preserve-tool-durability: false
  allow-vanilla-drops: false
  leaf-drop-enabled: true

hooks:
  worldguard:
    enabled: true
    deny-partial-breaks: true
  placeholderapi:
    enabled: true
```

</details>

### `messages.yml`

- Fully customizable player/admin messages.
- Supports placeholder replacements (`{prefix}`, `{player}`, `{time}`, `{tool}`, `{count}`, etc).
- Blacklist action-bar warning text is configurable, including `/tcmsg off` hint.

### Config Key Highlights

- `behavior.cut-leaves` (default `true`) - also fell the tree's leaves when cutting. Leaves only decay once the whole trunk is felled and only when no log supports them anymore (vanilla leaf-decay rule), so leaves of a neighbouring tree that merely touch are never removed. They never consume tool durability.
- `drops.leaf-drop-enabled` (default `true`) - whether felled leaves drop their natural vanilla drops (nothing, a stick, an apple for oak, ...). If `false`, felled leaves drop nothing.
- `drops.preserve-tool-durability` (default `false`) - when `true`, cutting never costs durability; leaves are always free.
- `hooks.worldguard.deny-partial-breaks` (default `true`) - cancel the whole cut if any protected block is inside the tree.
- `hooks.worldguard` - per-region control via the custom `treecutter` flag: `/rg flag <region> treecutter allow` makes the plugin work there, `deny` disables it there (default: allow).

---

## Notes

- `/tcmsg` does not show tab suggestions by design.
- If a player is unblacklisted while offline, the green unblacklist notice appears on next join.
- For region protection, keep `hooks.worldguard.enabled: true` and avoid giving `treecutter.bypass.worldguard` unless intended.
