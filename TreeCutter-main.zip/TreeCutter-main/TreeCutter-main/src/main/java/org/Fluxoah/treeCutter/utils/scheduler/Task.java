package org.Fluxoah.treeCutter.utils.scheduler;

public interface Task {

    void cancel();
}
