package org.Fluxoah.treeCutter.utils.scheduler;

import org.bukkit.entity.Player;

import java.util.function.Consumer;

public interface SchedulerAdapter {

    boolean isFolia();

    void runGlobal(Runnable task);

    void runAsync(Runnable task);

    Task runGlobalLater(Runnable task, long delayTicks);

    Task runGlobalTimer(Runnable task, long delayTicks, long periodTicks);

    Task runAsyncTimer(Runnable task, long delayTicks, long periodTicks);

    Task runEntityTimer(Player player, Consumer<Task> action, long delayTicks, long periodTicks);
}
