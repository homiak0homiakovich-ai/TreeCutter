package org.Fluxoah.treeCutter.utils.scheduler;

import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitScheduler;
import org.bukkit.scheduler.BukkitTask;

import java.util.function.Consumer;

public final class BukkitSchedulerAdapter implements SchedulerAdapter {

    private final JavaPlugin plugin;
    private final BukkitScheduler scheduler;

    public BukkitSchedulerAdapter(JavaPlugin plugin) {
        this.plugin = plugin;
        this.scheduler = plugin.getServer().getScheduler();
    }

    @Override
    public boolean isFolia() {
        return false;
    }

    @Override
    public void runGlobal(Runnable task) {
        scheduler.runTask(plugin, task);
    }

    @Override
    public void runAsync(Runnable task) {
        scheduler.runTaskAsynchronously(plugin, task);
    }

    @Override
    public Task runGlobalLater(Runnable task, long delayTicks) {
        return new BukkitTaskWrapper(scheduler.runTaskLater(plugin, task, delayTicks));
    }

    @Override
    public Task runGlobalTimer(Runnable task, long delayTicks, long periodTicks) {
        return new BukkitTaskWrapper(scheduler.runTaskTimer(plugin, task, delayTicks, periodTicks));
    }

    @Override
    public Task runAsyncTimer(Runnable task, long delayTicks, long periodTicks) {
        return new BukkitTaskWrapper(scheduler.runTaskTimerAsynchronously(plugin, task, delayTicks, periodTicks));
    }

    @Override
    public Task runEntityTimer(Player player, Consumer<Task> action, long delayTicks, long periodTicks) {
        final Task[] self = new Task[1];
        BukkitTask bukkitTask = scheduler.runTaskTimer(plugin, () -> {
            if (self[0] != null) {
                action.accept(self[0]);
            }
        }, delayTicks, periodTicks);
        BukkitTaskWrapper wrapper = new BukkitTaskWrapper(bukkitTask);
        self[0] = wrapper;
        return wrapper;
    }

    private static final class BukkitTaskWrapper implements Task {
        private final BukkitTask delegate;

        BukkitTaskWrapper(BukkitTask delegate) {
            this.delegate = delegate;
        }

        @Override
        public void cancel() {
            delegate.cancel();
        }
    }
}
