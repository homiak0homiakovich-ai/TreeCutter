package org.Fluxoah.treeCutter.utils;

import net.kyori.adventure.audience.Audience;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.entity.Player;

public final class ActionBarUtil {

    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();

    private ActionBarUtil() {
    }

    public static void send(Player player, String message) {
        if (message == null || message.isBlank()) {
            return;
        }
        Component component = LEGACY.deserialize(message);
        if (player instanceof Audience audience) {
            audience.sendActionBar(component);
        }
    }
}