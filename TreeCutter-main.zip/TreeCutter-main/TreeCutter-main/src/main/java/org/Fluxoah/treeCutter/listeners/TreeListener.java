package org.Fluxoah.treeCutter.listeners;

import org.Fluxoah.treeCutter.TreeCutter;
import org.Fluxoah.treeCutter.managers.*;
import org.Fluxoah.treeCutter.utils.ActionBarUtil;
import org.Fluxoah.treeCutter.utils.TreeUtils;
import org.Fluxoah.treeCutter.utils.scheduler.Task;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.*;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.atomic.AtomicInteger;

public class TreeListener implements Listener {

   private final TreeCutter plugin;
   private final ConfigManager config;
   private final MessageManager msg;
   private final PermissionManager perm;
   private final StatsManager stats;
   private final NoticeManager notices;
   private final PlacedLogManager placedLogs;
   private final Map<UUID, Long> cooldowns = new HashMap<>();
   private final Map<UUID, PendingConfirmation> confirmations = new HashMap<>();
   private final Map<UUID, Task> durabilityWarnings = new HashMap<>();

   public TreeListener(TreeCutter plugin) {
      this.plugin = plugin;
      this.config = plugin.getConfigManager();
      this.msg = plugin.getMessageManager();
      this.perm = plugin.getPermissionManager();
      this.stats = plugin.getStatsManager();
      this.notices = plugin.getNoticeManager();
      this.placedLogs = plugin.getPlacedLogManager();
   }

   @EventHandler(ignoreCancelled = true)
   public void onBlockBreak(BlockBreakEvent event) {
      Player player = event.getPlayer();
      Block block = event.getBlock();

      clearExpiredConfirmation(player);

      if (!config.getLogTypes().contains(block.getType())) {
         return;
      }

      if (!config.isServerEnabled()) {
         return;
      }

      if (!perm.canUseTreeFeller(player)) {
         return;
      }

      if (config.isPlayerDisabled(player.getUniqueId())) {
         return;
      }

      if (config.isSneakRequired() && !player.isSneaking()) {
         return;
      }

      if (config.isBlacklisted(player.getUniqueId())) {
         notices.showBlacklistWarning(player);
         return;
      }

      ItemStack tool = player.getInventory().getItemInMainHand();
      if (config.isRequireAxe() && !isAxe(tool)) {
         return;
      }

      double remainingCooldown = getCooldownRemaining(player);
      if (remainingCooldown > 0D) {
         player.sendMessage(msg.format("cooldown-active", "time", formatSeconds(remainingCooldown)));
         return;
      }

      var worldGuard = plugin.getWorldGuardHook();
      if (worldGuard != null
          && worldGuard.isEnabled()
          && !worldGuard.canBreakAll(player, List.of(block))) {
         return;
      }

      TreeUtils.TreeScanResult scanResult = TreeUtils.scanTree(block, config);
      if (config.shouldBlockPlayerMadeTrees() && scanResult.naturalMismatch()) {
         return;
      }
      if (!scanResult.validTree() || scanResult.blocks().isEmpty()) {
         return;
      }

      Set<Block> treeBlocks = scanResult.blocks();
      if (config.shouldBlockPlayerMadeTrees()
          && (config.isTrackPlayerPlacedLogs() || config.isTrackCommandPlacedLogs())
          && placedLogs.filterPlacedLogs(treeBlocks)) {
         return;
      }

      Set<Block> filtered = worldGuard != null ? worldGuard.filterCannotBreak(player, treeBlocks) : treeBlocks;
      if (filtered.isEmpty() || (filtered.size() != treeBlocks.size() && config.isDenyPartialBreaks())) {
         return;
      }
      treeBlocks = filtered;

      Set<Block> leafBlocks = Set.of();
      if (config.isCutLeaves()) {
         leafBlocks = worldGuard != null ? worldGuard.filterCannotBreak(player, scanResult.leaves()) : scanResult.leaves();
      }

      boolean confirmedDurabilityBreak = false;
      int remainingDurability = getRemainingDurability(tool);
      if (shouldConfirm(treeBlocks.size(), remainingDurability)) {
         if (!consumeConfirmation(player, block)) {
            event.setCancelled(true);
            setPendingConfirmation(player, treeBlocks);
            showDurabilityWarning(player, tool, remainingDurability, treeBlocks.size());
            return;
         }
         confirmedDurabilityBreak = true;
      }

      event.setCancelled(true);

      int broken = chopTree(player, leafBlocks, treeBlocks, tool, confirmedDurabilityBreak, remainingDurability);
      if (broken > 0) {
         confirmations.remove(player.getUniqueId());
         cancelDurabilityWarning(player);
         setCooldown(player);
      }
   }

   @EventHandler
   public void onPlayerQuit(PlayerQuitEvent event) {
      UUID uuid = event.getPlayer().getUniqueId();
      cooldowns.remove(uuid);
      confirmations.remove(uuid);
      cancelDurabilityWarning(uuid);
      notices.cancel(uuid);
   }

   private int chopTree(Player player, Collection<Block> leafBlocks, Collection<Block> treeBlocks, ItemStack tool, boolean suppressBreakMessage, int durability) {
      if (treeBlocks.isEmpty() && leafBlocks.isEmpty()) {
         return 0;
      }





      int limit = (durability <= 0 || config.shouldPreserveDurability()) ? Integer.MAX_VALUE : durability;
      int chopped = 0;
      Map<String, Integer> logsCounted = new HashMap<>();
      for (Block block : treeBlocks) {
         Material type = block.getType();
         logsCounted.merge(type.name(), 1, Integer::sum);

         breakBlock(block, tool, config.shouldDropItems());

         if (++chopped == limit) {
            break;
         }
      }




      if (chopped == treeBlocks.size()) {
         for (Block leaf : leafBlocks) {




            if (!TreeUtils.hasLogNearby(leaf, config)) {
               breakLeaves(leaf);
            }
         }
      }

      stats.recordTreeCut(player.getUniqueId(), logsCounted);
      if (!config.shouldPreserveDurability()) {
         handleToolDurability(player, tool, chopped, suppressBreakMessage);
      }
      return chopped;
   }

   private void breakBlock(Block block, ItemStack tool, boolean dropsEnabled) {
      if (config.allowVanillaDrops()) {
         block.breakNaturally(tool);
      } else if (dropsEnabled) {
         block.getWorld().dropItemNaturally(block.getLocation().add(0.5, 0.35, 0.5), new ItemStack(block.getType()));
      }
      block.setType(Material.AIR, false);
   }

   private void breakLeaves(Block leaf) {
      if (config.isLeafDropEnabled()) {
         leaf.breakNaturally();
      } else {
         leaf.setType(Material.AIR, false);
      }
   }

   private void handleToolDurability(Player player, ItemStack tool, int blocksBroken, boolean suppressBreakMessage) {
      if (tool == null || tool.getType().isAir() || blocksBroken == 0) {
         return;
      }

      ItemMeta meta = tool.getItemMeta();
      if (meta.isUnbreakable() || !(meta instanceof Damageable damageable)) {
         return;
      }

      int durabilityLoss = applyUnbreaking(blocksBroken, tool.getEnchantmentLevel(Enchantment.UNBREAKING));

      int maxDurability = tool.getType().getMaxDurability();
      int newDamage = damageable.getDamage() + durabilityLoss;

      if (maxDurability <= 0) {
         return;
      }

      if (newDamage >= maxDurability) {
         tool.setAmount(0);
         if (!suppressBreakMessage) {
            player.sendMessage(msg.format(
                  "tool-broke",
                  "tool", toolName(tool),
                  "count", String.valueOf(blocksBroken)
            ));
         }
         player.playSound(player.getLocation(), Sound.ENTITY_ITEM_BREAK, 1.0f, 1.0f);
         return;
      }

      damageable.setDamage(newDamage);
      tool.setItemMeta(damageable);
   }

   private boolean isAxe(ItemStack tool) {
      if (tool == null || tool.getType().isAir()) {
         return false;
      }
      return tool.getType().name().endsWith("_AXE");
   }

   private int getRemainingDurability(ItemStack tool) {
      if (tool == null || tool.getType().isAir()) {
         return -1;
      }

      ItemMeta meta = tool.getItemMeta();
      if (!(meta instanceof Damageable damageable) || meta.isUnbreakable()) {
         return -1;
      }

      int maxDurability = tool.getType().getMaxDurability();
      if (maxDurability <= 0) {
         return -1;
      }

      return Math.max(0, maxDurability - damageable.getDamage());
   }

   private boolean shouldConfirm(int treeSize, int remainingDurability) {
      return config.isConfirmationRequired()
             && !config.shouldPreserveDurability()
             && remainingDurability >= 0
             && treeSize >= remainingDurability;
   }

   private double getCooldownRemaining(Player player) {
      Long lastUse = cooldowns.get(player.getUniqueId());
      if (lastUse == null) {
         return 0D;
      }
      long cooldownMs = (long) (config.getCooldownSeconds() * 1000L);
      long remainingMs = cooldownMs - (System.currentTimeMillis() - lastUse);
      if (remainingMs <= 0L) {
         return 0D;
      }
      return remainingMs / 1000D;
   }

   private String formatSeconds(double seconds) {
      return String.valueOf((int) Math.ceil(seconds));
   }

   private void clearExpiredConfirmation(Player player) {
      PendingConfirmation pending = confirmations.get(player.getUniqueId());
      if (pending == null) {
         return;
      }
      if (pending.expiresAt() < System.currentTimeMillis()) {
         confirmations.remove(player.getUniqueId());
         cancelDurabilityWarning(player);
      }
   }

   private boolean consumeConfirmation(Player player, Block block) {
      PendingConfirmation pending = confirmations.get(player.getUniqueId());
      if (pending == null) {
         return false;
      }
      if (pending.expiresAt() < System.currentTimeMillis()) {
         confirmations.remove(player.getUniqueId());
         return false;
      }
      if (!pending.trees().contains(block.getLocation())) {
         return false;
      }
      confirmations.remove(player.getUniqueId());
      return true;
   }

   private void setPendingConfirmation(Player player, Collection<Block> treeBlocks) {
      cancelDurabilityWarning(player);
      long expiresAt = System.currentTimeMillis() + config.getConfirmationTimeSeconds() * 1000L;
      confirmations.put(player.getUniqueId(), new PendingConfirmation(toBlockKeys(treeBlocks), expiresAt));
   }




   private void showDurabilityWarning(Player player, ItemStack tool, int remainingDurability, int needed) {
      cancelDurabilityWarning(player);
      UUID playerId = player.getUniqueId();
      String message = msg.format(
            "tool-will-break",
            "tool", toolName(tool),
            "remaining", String.valueOf(remainingDurability),
            "needed", String.valueOf(needed),
            "time", String.valueOf(config.getConfirmationTimeSeconds())
      );
      AtomicInteger remainingSends = new AtomicInteger(Math.max(1, config.getConfirmationTimeSeconds()));
      Task task = plugin.getScheduler().runEntityTimer(player, self -> {
         Player online = plugin.getServer().getPlayer(playerId);
         if (online == null || !online.isOnline()) {
            self.cancel();
            durabilityWarnings.remove(playerId);
            return;
         }
         ActionBarUtil.send(online, message);
         if (remainingSends.decrementAndGet() <= 0) {
            self.cancel();
            durabilityWarnings.remove(playerId);
         }
      }, 1L, 20L);
      durabilityWarnings.put(playerId, task);
   }

   private void cancelDurabilityWarning(Player player) {
      cancelDurabilityWarning(player.getUniqueId());
   }

   private void cancelDurabilityWarning(UUID playerId) {
      Task task = durabilityWarnings.remove(playerId);
      if (task != null) {
         task.cancel();
      }
   }

   private Set<Location> toBlockKeys(Collection<Block> blocks) {
      Set<Location> keys = new HashSet<>(Math.max(16, blocks.size()));
      for (Block block : blocks) {
         keys.add(block.getLocation());
      }
      return keys;
   }


   private int applyUnbreaking(int baseLoss, int unbreakingLevel) {
      if (unbreakingLevel <= 0) {
         return baseLoss;
      }

      double chance = 1.0 / (unbreakingLevel + 1);
      return (int) ThreadLocalRandom.current().doubles(baseLoss).filter((d) -> d < chance).count();
   }

   private void setCooldown(Player player) {
      cooldowns.put(player.getUniqueId(), System.currentTimeMillis());
   }

   private String toolName(ItemStack tool) {
      if (tool == null || tool.getType().isAir()) {
         return "tool";
      }
      ItemMeta meta = tool.getItemMeta();
      if (meta != null && meta.hasDisplayName()) {
         return LegacyComponentSerializer.legacySection().serialize(meta.displayName());
      }
      String raw = tool.getType().name().toLowerCase(Locale.ROOT);
      StringBuilder builder = new StringBuilder();
      for (String part : raw.split("_")) {
         if (part.isEmpty()) {
            continue;
         }
         builder.append(Character.toUpperCase(part.charAt(0)))
                .append(part.substring(1))
                .append(' ');
      }
      return builder.toString().trim();
   }

   private record PendingConfirmation(Set<Location> trees, long expiresAt) {
   }
}
