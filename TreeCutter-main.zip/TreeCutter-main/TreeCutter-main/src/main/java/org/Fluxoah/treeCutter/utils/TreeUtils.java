package org.Fluxoah.treeCutter.utils;

import org.Fluxoah.treeCutter.managers.ConfigManager;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;

import java.util.*;

public final class TreeUtils {

   public static final Comparator<Block> COMPARATOR_BLOCK = Comparator
         .comparingInt(Block::getY)
         .thenComparingInt(Block::getX)
         .thenComparingInt(Block::getZ);




   private static final int[][] LOG_SCAN_OFFSETS = {
         {0, 1, 0}, {0, -1, 0},
         {1, 0, 0}, {-1, 0, 0}, {0, 0, 1}, {0, 0, -1},
         {1, 0, 1}, {1, 0, -1}, {-1, 0, 1}, {-1, 0, -1},
         {1, 1, 0}, {1, -1, 0}, {-1, 1, 0}, {-1, -1, 0},
         {0, 1, 1}, {0, 1, -1}, {0, -1, 1}, {0, -1, -1},
         {1, 1, 1}, {1, 1, -1}, {-1, 1, 1}, {-1, 1, -1},
         {1, -1, 1}, {1, -1, -1}, {-1, -1, 1}, {-1, -1, -1}
   };







public static final int LEAF_DECAY_RADIUS = 2;

   private TreeUtils() {
   }

   public static TreeScanResult scanTree(Block start, ConfigManager config) {
      if (!config.getLogTypes().contains(start.getType())) {
         return TreeScanResult.invalid();
      }

      Queue<Block> queue = new ArrayDeque<>();
      Set<Location> visited = new HashSet<>();
      Set<Block> result = new TreeSet<>(COMPARATOR_BLOCK);
      int baseX = start.getX();
      int baseZ = start.getZ();
      int maxTreeSize = config.getMaxTreeSize();
      int leafCount = 0;
      int minY = start.getY();
      int maxY = start.getY();
      boolean foundUpwardGrowth = false;

      queue.add(start);
      visited.add(start.getLocation());

      while (!queue.isEmpty()) {
         Block current = queue.poll();
         result.add(current);

         if (result.size() > maxTreeSize) {
            return new TreeScanResult(result, false, true, false, Set.of());
         }

         minY = Math.min(minY, current.getY());
         maxY = Math.max(maxY, current.getY());
         if (current.getY() > start.getY()) {
            foundUpwardGrowth = true;
         }

         int spreadX = Math.abs(current.getX() - baseX);
         int spreadZ = Math.abs(current.getZ() - baseZ);
         if (spreadX > config.getMaxHorizontalSpread() || spreadZ > config.getMaxHorizontalSpread()) {
            return new TreeScanResult(result, false, true, false, Set.of());
         }

         leafCount += countNearbyLeaves(current, config);

         for (int[] offset : LOG_SCAN_OFFSETS) {
            Block relative = current.getRelative(offset[0], offset[1], offset[2]);
            if (!config.getLogTypes().contains(relative.getType())) {
               continue;
            }

            if (visited.add(relative.getLocation())) {
               queue.add(relative);
            }
         }
      }

      leafCount = Math.min(leafCount, maxTreeSize * 4);
      boolean validLeaves = !config.isNaturalLogsOnly() || leafCount >= config.getMinLeafCount();
      boolean validGrowth = !config.isRequireUpwardGrowth() || foundUpwardGrowth || maxY > minY;
      boolean naturalMismatch = config.isNaturalLogsOnly() && !(validLeaves && validGrowth);
      boolean validTree = validLeaves && validGrowth;

      Set<Block> leaves = validTree ? collectLeaves(result, config) : Set.of();

      return new TreeScanResult(result, validTree, false, naturalMismatch, leaves);
   }

   private static Set<Block> collectLeaves(Set<Block> logs, ConfigManager config) {
      Set<Location> leafLocs = new HashSet<>();
      for (Block log : logs) {
         for (int x = -config.getMaxLeafSearchRadius(); x <= config.getMaxLeafSearchRadius(); x++) {
            for (int y = -1; y <= config.getMaxLeafSearchUp(); y++) {
               for (int z = -config.getMaxLeafSearchRadius(); z <= config.getMaxLeafSearchRadius(); z++) {
                  Block relative = log.getRelative(x, y, z);
                  if (config.getLeafTypes().contains(relative.getType())) {
                     leafLocs.add(relative.getLocation());
                  }
               }
            }
         }
      }
      Set<Block> leaves = new TreeSet<>(COMPARATOR_BLOCK);
      for (Location loc : leafLocs) {
         leaves.add(loc.getBlock());
      }
      return leaves;
   }

   private static int countNearbyLeaves(Block block, ConfigManager config) {
      int count = 0;
      for (int x = -config.getMaxLeafSearchRadius(); x <= config.getMaxLeafSearchRadius(); x++) {
         for (int y = -1; y <= config.getMaxLeafSearchUp(); y++) {
            for (int z = -config.getMaxLeafSearchRadius(); z <= config.getMaxLeafSearchRadius(); z++) {
               Material type = block.getRelative(x, y, z).getType();
               if (config.getLeafTypes().contains(type)) {
                  count++;
               }
            }
         }
      }
      return count;
   }


   public static boolean hasLogNearby(Block leaf, ConfigManager config) {


      for (int distance = 1; distance <= LEAF_DECAY_RADIUS; distance++) {
         if (isLogAt(leaf, config, 0, distance, 0)
               || isLogAt(leaf, config, 0, -distance, 0)
               || isLogAt(leaf, config, distance, 0, 0)
               || isLogAt(leaf, config, -distance, 0, 0)
               || isLogAt(leaf, config, 0, 0, distance)
               || isLogAt(leaf, config, 0, 0, -distance)) {
            return true;
         }
      }
      return false;
   }

   private static boolean isLogAt(Block leaf, ConfigManager config, int dx, int dy, int dz) {
      return config.getLogTypes().contains(leaf.getRelative(dx, dy, dz).getType());
   }

   public record TreeScanResult(Set<Block> blocks, boolean validTree, boolean tooLarge, boolean naturalMismatch, Set<Block> leaves) {
      public static TreeScanResult invalid() {
         return new TreeScanResult(Set.of(), false, false, false, Set.of());
      }
   }
}
