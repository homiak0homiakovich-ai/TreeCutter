package org.Fluxoah.treeCutter.utils;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.Fluxoah.treeCutter.TreeCutter;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class UpdateChecker {

    public static final String MODRINTH_PROJECT_ID = "FEtr8Tdw";
    public static final String MODRINTH_URL = "https://modrinth.com/plugin/tree-cutter+";
    public static final String ISSUES_URL = "https://github.com/Fluxoah/TreeCutter/issues";

    private static final String API_BASE = "https://api.modrinth.com/v2";
    private static final int CONNECT_TIMEOUT_MS = 4000;
    private static final int READ_TIMEOUT_MS = 4000;

    private final TreeCutter plugin;

    public UpdateChecker(TreeCutter plugin) {
        this.plugin = plugin;
    }

    public void announceBugReportLink() {
        plugin.getLogger().info("Found a bug? Report it at " + ISSUES_URL);
    }

    public void checkForUpdates() {
        String minecraftVersion = normalizeMinecraftVersion(Bukkit.getBukkitVersion());
        List<String> loaders = resolveLoaders();

        plugin.getScheduler().runAsync(() -> {
            Result result;
            try {
                List<RemoteVersion> candidates = fetchVersionsFor(minecraftVersion, loaders);
                result = resolvePluginVersion(candidates);
            } catch (Exception exception) {
                plugin.getLogger().warning("Update check failed: " + exception.getMessage());
                return;
            }
            plugin.getScheduler().runGlobal(() -> report(result));
        });
    }

    private Result resolvePluginVersion(List<RemoteVersion> candidates) {
        String installed = plugin.getPluginMeta().getVersion();
        RemoteVersion best = null;
        for (RemoteVersion candidate : candidates) {
            if (compareVersions(candidate.versionNumber, installed) > 0) {
                if (best == null || compareVersions(candidate.versionNumber, best.versionNumber) > 0) {
                    best = candidate;
                }
            }
        }
        return new Result(installed, best, detectServerType());
    }

    private void report(Result result) {
        if (result.latest == null) {
            String upToDate = colorize(prefix()
                    + " \u00A77You are running the latest TreeCutter version \u00A7a("
                    + result.installed + ")\u00A77.");
            plugin.getLogger().info(stripLegacy(upToDate));
            return;
        }

        String versionUrl = MODRINTH_URL + "/version/" + result.latest.versionNumber;

        String header = colorize(prefix()
                + " \u00A77A newer version of \u00A7bTreeCutter \u00A77is available! "
                + "\u00A78\u00BB \u00A7a" + result.latest.versionNumber
                + " \u00A78(\u00A7cinstalled: \u00A78" + result.installed + "\u00A78)");
        String link = colorize("\u00A7b\u00A7l" + versionUrl);

        plugin.getLogger().info(stripLegacy(header));
        plugin.getLogger().info(stripLegacy(link));
        plugin.setPendingUpdateMessage(header + "\n" + link);

        Bukkit.getOnlinePlayers().stream()
                .filter(Player::isOp)
                .forEach(player -> player.sendMessage(header + "\n" + link));
    }

    private String prefix() {
        String configured = plugin.getConfig().getString("prefix");
        if (configured == null || configured.isBlank()) {
            return "&8[&3T&bC&8]";
        }
        return configured;
    }

    private static String colorize(String input) {
        if (input == null || input.isEmpty()) {
            return "";
        }
        StringBuilder result = new StringBuilder(input.length());
        char[] chars = input.toCharArray();
        for (int i = 0; i < chars.length; i++) {
            char c = chars[i];
            if (c == '&' && i + 1 < chars.length && isColorCode(chars[i + 1])) {
                result.append('\u00A7').append(Character.toLowerCase(chars[i + 1]));
                i++;
            } else {
                result.append(c);
            }
        }
        return result.toString();
    }

    private static boolean isColorCode(char c) {
        return "0123456789AaBbCcDdEeFfKkLlMmNnOoRrXx".indexOf(c) != -1;
    }

    private static String stripLegacy(String input) {
        if (input == null) {
            return "";
        }
        return input.replaceAll("\u00A7[0-9A-Fa-fK-Ok-ofxXrRlLmMnNoO]", "");
    }

    private List<RemoteVersion> fetchVersionsFor(String minecraftVersion, List<String> loaders) throws IOException {
        URI uri = URI.create(API_BASE + "/project/" + MODRINTH_PROJECT_ID + "/version");

        HttpURLConnection connection = (HttpURLConnection) uri.toURL().openConnection();
        connection.setConnectTimeout(CONNECT_TIMEOUT_MS);
        connection.setReadTimeout(READ_TIMEOUT_MS);
        connection.setRequestProperty("User-Agent", "TreeCutter/" + plugin.getPluginMeta().getVersion() + " (Fluxoah/TreeCutter)");
        connection.setRequestMethod("GET");

        int code = connection.getResponseCode();
        if (code != 200) {
            connection.disconnect();
            throw new IOException("Modrinth API returned HTTP " + code);
        }

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8))) {
            JsonArray versions = JsonParser.parseReader(reader).getAsJsonArray();
            List<RemoteVersion> result = new ArrayList<>();
            for (JsonElement element : versions) {
                JsonObject version = element.getAsJsonObject();
                List<String> gameVersions = toStringList(version.getAsJsonArray("game_versions"));
                List<String> versionLoaders = toStringList(version.getAsJsonArray("loaders"));
                String versionNumber = version.get("version_number").getAsString();
                if (versionNumber == null || versionNumber.isEmpty()) {
                    continue;
                }
                if (!gameVersions.contains(minecraftVersion)) {
                    continue;
                }
                if (!matchesAnyLoader(versionLoaders, loaders)) {
                    continue;
                }
                String downloadUrl = pickDownloadUrl(version.getAsJsonArray("files"));
                result.add(new RemoteVersion(versionNumber, gameVersions, downloadUrl));
            }
            return result;
        } finally {
            connection.disconnect();
        }
    }

    private boolean matchesAnyLoader(List<String> versionLoaders, List<String> expectedLoaders) {
        for (String loader : expectedLoaders) {
            if (versionLoaders.contains(loader)) {
                return true;
            }
        }
        return false;
    }

    private String pickDownloadUrl(JsonArray files) {
        if (files == null) {
            return MODRINTH_URL;
        }
        for (JsonElement element : files) {
            JsonObject file = element.getAsJsonObject();
            if (file.get("primary") != null && file.get("primary").getAsBoolean()) {
                String url = file.get("url") != null ? file.get("url").getAsString() : null;
                if (url != null && !url.isEmpty()) {
                    return url;
                }
            }
        }
        return MODRINTH_URL;
    }

    private List<String> toStringList(JsonArray array) {
        List<String> values = new ArrayList<>();
        if (array == null) {
            return values;
        }
        for (JsonElement element : array) {
            values.add(element.getAsString());
        }
        return values;
    }

    static List<String> resolveLoaders() {
        String serverType = detectServerType();
        switch (serverType) {
            case "folia":
                return List.of("folia", "paper");
            case "purpur":
                return List.of("purpur", "paper");
            case "paper":
                return List.of("paper", "spigot", "bukkit");
            case "spigot":
                return List.of("spigot", "paper");
            case "bukkit":
                return List.of("bukkit", "spigot", "paper");
            default:
                return List.of("paper", "spigot", "bukkit", "folia", "purpur");
        }
    }

    static String detectServerType() {
        String name = Bukkit.getName();
        if (name == null) {
            return "unknown";
        }
        switch (name.toLowerCase(Locale.ROOT)) {
            case "folia":
                return "folia";
            case "purpur":
                return "purpur";
            case "paper":
            case "paper 1.21.1":
            case "paperspigot":
                return "paper";
            case "spigot":
                return "spigot";
            case "craftbukkit":
            case "bukkit":
                return "bukkit";
            default:
                return "unknown";
        }
    }

    static int compareVersions(String first, String second) {
        String[] firstParts = first.split("\\.");
        String[] secondParts = second.split("\\.");
        int length = Math.max(firstParts.length, secondParts.length);
        for (int i = 0; i < length; i++) {
            int firstValue = i < firstParts.length ? parseNumber(firstParts[i]) : 0;
            int secondValue = i < secondParts.length ? parseNumber(secondParts[i]) : 0;
            if (firstValue != secondValue) {
                return Integer.compare(firstValue, secondValue);
            }
        }
        return 0;
    }

    private static int parseNumber(String part) {
        String digits = part.replaceAll("[^0-9]", "");
        if (digits.isEmpty()) {
            return 0;
        }
        try {
            return Integer.parseInt(digits);
        } catch (NumberFormatException exception) {
            return 0;
        }
    }

    static String normalizeMinecraftVersion(String bukkitVersion) {
        String base = bukkitVersion.split("-", 2)[0];
        return base.toLowerCase(Locale.ROOT).trim();
    }

    static final class RemoteVersion {
        final String versionNumber;
        final List<String> gameVersions;
        final String downloadUrl;

        RemoteVersion(String versionNumber, List<String> gameVersions, String downloadUrl) {
            this.versionNumber = versionNumber;
            this.gameVersions = gameVersions;
            this.downloadUrl = downloadUrl;
        }
    }

    static final class Result {
        final String installed;
        final RemoteVersion latest;
        final String serverType;

        Result(String installed, RemoteVersion latest, String serverType) {
            this.installed = installed;
            this.latest = latest;
            this.serverType = serverType;
        }
    }
}
