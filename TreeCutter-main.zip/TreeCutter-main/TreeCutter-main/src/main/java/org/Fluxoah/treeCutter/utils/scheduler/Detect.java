package org.Fluxoah.treeCutter.utils.scheduler;

public final class Detect {

    private static final boolean FOLIA;

    static {
        boolean folia = false;
        try {



            Class.forName("io.papermc.paper.threadedregions.RegionizedServer");
            folia = true;
        } catch (ClassNotFoundException ignored) {
        }
        FOLIA = folia;
    }

    private Detect() {
    }

    public static boolean isFolia() {
        return FOLIA;
    }
}
