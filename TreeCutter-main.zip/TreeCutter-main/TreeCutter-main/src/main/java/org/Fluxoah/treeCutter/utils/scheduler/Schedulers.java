package org.Fluxoah.treeCutter.utils.scheduler;

import org.bukkit.plugin.java.JavaPlugin;

public final class Schedulers {

    private Schedulers() {
    }

    public static SchedulerAdapter forPlugin(JavaPlugin plugin) {
        return Detect.isFolia() ? new FoliaSchedulerAdapter(plugin) : new BukkitSchedulerAdapter(plugin);
    }
}
