package org.Fluxoah.treeCutter.utils.scheduler;

import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

public final class FoliaSchedulerAdapter implements SchedulerAdapter {

    private static final String SCHEDULER_PACKAGE = "io.papermc.paper.threadedregions.scheduler";

    private final JavaPlugin plugin;
    private final Object globalScheduler;
    private final Object asyncScheduler;

    private final Method globalRun;
    private final Method globalRunDelayed;
    private final Method globalRunAtFixedRate;
    private final Method globalExecute;

    private final Method asyncRunNow;
    private final Method asyncRunAtFixedRate;
    private final boolean asyncRunAtFixedRateConsumer;

    private final Method playerGetScheduler;
    private final Method entityRunAtFixedRate;

    private final Method scheduledTaskCancel;

    public FoliaSchedulerAdapter(JavaPlugin plugin) {
        this.plugin = plugin;
        try {
            Object server = plugin.getServer();
            Class<?> serverClass = server.getClass();

            this.globalScheduler = serverClass.getMethod("getGlobalRegionScheduler").invoke(server);
            this.asyncScheduler = serverClass.getMethod("getAsyncScheduler").invoke(server);

            Class<?> globalCls = globalScheduler.getClass();
            this.globalExecute = firstMethod(globalCls, "execute", params(Plugin.class, Runnable.class));
            this.globalRun = firstMethod(globalCls, "run",
                    params(Plugin.class, Consumer.class),
                    params(Plugin.class, Runnable.class));
            this.globalRunDelayed = firstMethod(globalCls, "runDelayed",
                    params(Plugin.class, Consumer.class, long.class),
                    params(Plugin.class, Runnable.class, long.class));
            this.globalRunAtFixedRate = firstMethod(globalCls, "runAtFixedRate",
                    params(Plugin.class, Consumer.class, long.class, long.class),
                    params(Plugin.class, Runnable.class, long.class, long.class));

            Class<?> asyncCls = asyncScheduler.getClass();
            this.asyncRunNow = firstMethod(asyncCls, "runNow",
                    params(Plugin.class, Consumer.class),
                    params(Plugin.class, Runnable.class));

            this.asyncRunAtFixedRate = firstMethod(asyncCls, "runAtFixedRate",
                    params(Plugin.class, Consumer.class, long.class, long.class, TimeUnit.class),
                    params(Plugin.class, Runnable.class, long.class, TimeUnit.class, long.class, TimeUnit.class));
            this.asyncRunAtFixedRateConsumer = asyncRunAtFixedRate.getParameterTypes()[1] != Runnable.class;

            this.playerGetScheduler = Player.class.getMethod("getScheduler");
            Class<?> entitySchedulerCls = Class.forName(SCHEDULER_PACKAGE + ".EntityScheduler");
            this.entityRunAtFixedRate = firstMethod(entitySchedulerCls, "runAtFixedRate",
                    params(Plugin.class, Consumer.class, Runnable.class, long.class, long.class),
                    params(Plugin.class, Runnable.class, Runnable.class, long.class, long.class));

            this.scheduledTaskCancel = Class.forName(SCHEDULER_PACKAGE + ".ScheduledTask").getMethod("cancel");
        } catch (Exception ex) {
            throw new IllegalStateException("Failed to initialise the Folia scheduler adapter", ex);
        }
    }

    private static Class<?>[] params(Class<?>... types) {
        return types;
    }




    private static Object taskArg(Method method, Runnable task) {
        Class<?> paramType = method.getParameterTypes()[1];
        if (paramType.equals(Runnable.class)) {
            return task;
        }
        return (Consumer<Object>) ignored -> task.run();
    }

    private static Method firstMethod(Class<?> type, String name, Class<?>[]... candidates)
            throws NoSuchMethodException {
        for (Class<?>[] candidate : candidates) {
            try {
                return type.getMethod(name, candidate);
            } catch (NoSuchMethodException ignored) {
            }
        }
        throw new NoSuchMethodException(type.getName() + "." + name);
    }

    @Override
    public boolean isFolia() {
        return true;
    }

    @Override
    public void runGlobal(Runnable task) {
        try {
            if (globalExecute != null) {
                globalExecute.invoke(globalScheduler, plugin, task);
            } else if (globalRun != null) {
                globalRun.invoke(globalScheduler, plugin, taskArg(globalRun, task));
            } else {
                throw new IllegalStateException("GlobalRegionScheduler has no run/execute method");
            }
        } catch (IllegalAccessException | InvocationTargetException ex) {
            throw new RuntimeException("Failed to schedule global task", ex);
        }
    }

    @Override
    public void runAsync(Runnable task) {
        try {
            asyncRunNow.invoke(asyncScheduler, plugin, taskArg(asyncRunNow, task));
        } catch (IllegalAccessException | InvocationTargetException ex) {
            throw new RuntimeException("Failed to schedule async task", ex);
        }
    }

    @Override
    public Task runGlobalLater(Runnable task, long delayTicks) {
        Object arg = taskArg(globalRunDelayed, task);
        return wrapInvoke(() -> globalRunDelayed.invoke(globalScheduler, plugin, arg, delayTicks));
    }

    @Override
    public Task runGlobalTimer(Runnable task, long delayTicks, long periodTicks) {
        Object arg = taskArg(globalRunAtFixedRate, task);
        return wrapInvoke(() -> globalRunAtFixedRate.invoke(globalScheduler, plugin, arg, delayTicks, periodTicks));
    }

    @Override
    public Task runAsyncTimer(Runnable task, long delayTicks, long periodTicks) {
        long delayMilliseconds = delayTicks * 50L;
        long periodMilliseconds = periodTicks * 50L;
        Object arg = taskArg(asyncRunAtFixedRate, task);
        return wrapInvoke(() -> {
            if (asyncRunAtFixedRateConsumer) {

                return asyncRunAtFixedRate.invoke(asyncScheduler, plugin, arg,
                        delayMilliseconds, periodMilliseconds, TimeUnit.MILLISECONDS);
            }

            return asyncRunAtFixedRate.invoke(asyncScheduler, plugin, arg,
                    delayMilliseconds, TimeUnit.MILLISECONDS, periodMilliseconds, TimeUnit.MILLISECONDS);
        });
    }

    @Override
    public Task runEntityTimer(Player player, Consumer<Task> action, long delayTicks, long periodTicks) {
        try {
            Object entityScheduler = playerGetScheduler.invoke(player);
            Consumer<Object> onTick = scheduledTask -> {
                Task wrapper = new ScheduledTaskWrapper(scheduledTask, scheduledTaskCancel);
                action.accept(wrapper);
            };
            Runnable retired = () -> {
            };
            Object scheduledTask = entityRunAtFixedRate.invoke(entityScheduler, plugin, onTick, retired, delayTicks, periodTicks);
            return new ScheduledTaskWrapper(scheduledTask, scheduledTaskCancel);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            throw new RuntimeException("Failed to schedule entity task", ex);
        }
    }

    private Task wrapInvoke(ThrowingSupplier supplier) {
        try {
            return new ScheduledTaskWrapper(supplier.get(), scheduledTaskCancel);
        } catch (InvocationTargetException | IllegalAccessException ex) {
            throw new RuntimeException("Failed to schedule task", ex);
        }
    }

    @FunctionalInterface
    private interface ThrowingSupplier {
        Object get() throws InvocationTargetException, IllegalAccessException;
    }

    private static final class ScheduledTaskWrapper implements Task {
        private final Object delegate;
        private final Method cancelMethod;

        ScheduledTaskWrapper(Object delegate, Method cancelMethod) {
            this.delegate = delegate;
            this.cancelMethod = cancelMethod;
        }

        @Override
        public void cancel() {
            try {
                cancelMethod.invoke(delegate);
            } catch (IllegalAccessException | InvocationTargetException ex) {
                throw new RuntimeException("Failed to cancel scheduled task", ex);
            }
        }
    }
}
